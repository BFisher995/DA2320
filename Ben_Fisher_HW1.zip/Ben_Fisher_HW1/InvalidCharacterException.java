package Ben_Fisher_HW1;

public class InvalidCharacterException extends RuntimeException {
    public InvalidCharacterException(String mssg) {
        super(mssg);
    }
}        
